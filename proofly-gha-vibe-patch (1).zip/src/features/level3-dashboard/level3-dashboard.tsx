import React from 'react';

export default function Level3Dashboard() {
  return (
    <div className="p-6 space-y-4">
      <h1 className="text-2xl font-semibold">Proofly • Level-3 Dashboard</h1>
      <div className="grid md:grid-cols-3 gap-4">
        <div className="rounded-xl p-4 shadow bg-white">Avg Fairness: 4.3</div>
        <div className="rounded-xl p-4 shadow bg-white">p95 Wait Time: 5d</div>
        <div className="rounded-xl p-4 shadow bg-white">Bias Flags: 2</div>
      </div>
      <div className="rounded-xl p-4 shadow bg-white">[Trend Chart Placeholder]</div>
    </div>
  );
}
