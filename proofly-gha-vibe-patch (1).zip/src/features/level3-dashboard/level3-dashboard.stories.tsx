import React from 'react';
import Level3Dashboard from './level3-dashboard';

export default {
  title: 'Features/Level3Dashboard',
  component: Level3Dashboard,
};

export const Preview = () => <Level3Dashboard />;
