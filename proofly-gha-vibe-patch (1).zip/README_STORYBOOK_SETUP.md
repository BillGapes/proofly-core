# One-time Storybook Setup

Install dev dependencies:

```bash
npm i -D @storybook/react @storybook/addon-essentials @storybook/addon-interactions @storybook/testing-library @storybook/react-vite vite
```

Then you can build the preview:

```bash
npm run build-storybook
```

Your CI will publish the preview from `storybook-static/`.
